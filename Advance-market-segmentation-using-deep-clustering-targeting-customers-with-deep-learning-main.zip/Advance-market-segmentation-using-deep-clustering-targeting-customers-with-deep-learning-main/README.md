# Advance-market-segmentation-using-deep-clustering-targeting-customers-with-deep-learning
Advance market segmentation using deep clustering targeting customers with deep learning
